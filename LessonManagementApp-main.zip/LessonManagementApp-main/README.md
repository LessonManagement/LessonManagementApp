# Backend
Proyecto de gestion de lecciones LessonManagement

## Instalación
1. Crear una rama en el repositorio para trabajar
2. Clonar el repositorio
3. Realizar instalacion de proyecto en visual studio
```bash
cd laravel
composer install
```
4. Realizar migraciones de la base de datos (cuando las haya)
```bash
php artisan migrate
```